/*
  ==============================================================================

    OscData.cpp
    Author:  Xiaohe Tian

  ==============================================================================
*/

#include "OscData.h"

void OscData::prepareToPlay (double sampleRate, int samplesPerBlock, int outputChannels)
{
    resetAll();
    
    juce::dsp::ProcessSpec spec;
    spec.maximumBlockSize = samplesPerBlock;
    spec.sampleRate = sampleRate;
    spec.numChannels = outputChannels;
    
    sampRate = sampleRate;

    prepare (spec);
    fmOsc.prepare (spec);
    gain.prepare (spec);
}

void OscData::setType (WaveMixData oscWave, const bool oscEnable)
{
    auto waveValueTotal = oscWave.sine + oscWave.square + oscWave.triangle + oscWave.saw;
    if (oscEnable == false)
    {
        initialise([](float x) { return 0; });
    }
    else if (waveValueTotal < 1.0f )
    {
        initialise([oscWave](float x) { return (std::sin(x) * oscWave.sine) +
           ((x < 0.0f ? -1.0f : 1.0f) * oscWave.square) + 
            ((x < 0.0f ? x * 2 / juce::MathConstants<float>::pi + 1 : x * (-2) / juce::MathConstants<float>::pi + 1) * oscWave.triangle) + 
            (x / juce::MathConstants<float>::pi * oscWave.saw); });
        //initialise([](float x) { return std::sin(x); });
    }
    else
    {
        initialise([oscWave, waveValueTotal](float x) { return (std::sin(x) * oscWave.sine / waveValueTotal) +
            ((x < 0.0f ? -1.0f : 1.0f) * oscWave.square / waveValueTotal) +
            ((x < 0.0f ? x * 2 / juce::MathConstants<float>::pi + 1 : x * (-2) / juce::MathConstants<float>::pi + 1) * oscWave.triangle / waveValueTotal) +
            (x / juce::MathConstants<float>::pi * oscWave.saw / waveValueTotal); });
        //initialise([](float x) { return std::sin(x); });
    }

}

void OscData::setGain (const float levelInDecibels)
{
    gain.setGainDecibels (levelInDecibels);
}

void OscData::setOscPitch (const int pitch)
{
    lastPitch = pitch;
    // setFrequency (juce::MidiMessage::getMidiNoteInHertz ((lastMidiNote + lastPitch) + fmModulator)); // why this expression? 
    if (fmEnable)
    {
        setFrequency(juce::MidiMessage::getMidiNoteInHertz((lastMidiNote+lastPitch) + fmModulator * lastMidiNote));
    }
    else
    {
        setFrequency(juce::MidiMessage::getMidiNoteInHertz(lastMidiNote + lastPitch)); // test
    }
}

void OscData::setFreq (const int midiNoteNumber)
{
    // setFrequency (juce::MidiMessage::getMidiNoteInHertz ((midiNoteNumber + lastPitch) + fmModulator)); // why this expression? 
    if (fmEnable)
    {
        setFrequency(juce::MidiMessage::getMidiNoteInHertz((midiNoteNumber + lastPitch) + fmModulator * midiNoteNumber));
    }
    else
    {
        setFrequency(juce::MidiMessage::getMidiNoteInHertz(midiNoteNumber + lastPitch)); // test
    }
    lastMidiNote = midiNoteNumber;

    fmEnvLevel = 0.0;
    fmEnvMode = 0;
    counter = 0;
    DBG("setFreq");
}

void OscData::setFmOsc (FmData fm, FmEnvData fmEnv)
{
    fmEnvSelect = fmEnv.select;
    fmEnvAttack = fmEnv.attack;
    fmEnvDecay = fmEnv.decay;
    fmEnvSustain = fmEnv.sustain;
    decayRate = (1.0 - fmEnvSustain) / (fmEnvDecay * sampRate / 1000);

    fmEnable = fm.enable;
    fmDepth = fm.depth;
    fmOsc.setFrequency (fm.freq);

    auto midiNoteFreq = juce::MidiMessage::getMidiNoteInHertz(lastMidiNote + lastPitch);


    if (fmEnable)
    {
        DBG("fmModulator: " << fmModulator << " lastMidiNote: " << lastMidiNote << " counter: " << counter << " midiNoteFreq: " << midiNoteFreq);
        setFrequency(juce::MidiMessage::getMidiNoteInHertz((lastMidiNote + lastPitch) + fmModulator * lastMidiNote));
        switch(fmEnvSelect)
        {
        case 0: // Off
            fmEnvLevel = 1.0;
            break;
        case 1: // ADS
            attackRate = 1.0 / (fmEnvAttack * sampRate / 1000);
            if (fmEnvMode == 0) // attack mode
            {
                if (fmEnvLevel + attackRate < 1.0)
                {
                    fmEnvLevel += attackRate;
                }
                else
                {
                    fmEnvLevel = 1.0;
                    fmEnvMode = 1; // switch to delay/sustain mode
                }
            }
            else if (fmEnvMode == 1)
            {
                if (fmEnvLevel - decayRate > fmEnvSustain)
                {
                    fmEnvLevel -= decayRate;
                }
                else
                {
                    fmEnvLevel = fmEnvSustain;
                }
            }
            //fmEnvLevel = ((fmEnvLevel - decayRate) > fmEnvSustain) ? (fmEnvLevel - decayRate) : fmEnvSustain;
            break;
        case 2: // Wave
            attackRate = (1.0 - fmEnvSustain) / (fmEnvAttack * sampRate / 1000);
            if (fmEnvLevel < fmEnvSustain)
                fmEnvLevel = fmEnvSustain;
            if (fmEnvMode == 0) // attack mode
            {
                if (fmEnvLevel + attackRate < 1.0)
                {
                    fmEnvLevel += attackRate;
                }
                else
                {
                    fmEnvLevel = 1.0;
                    fmEnvMode = 1; // switch to delay/sustain mode
                }
            }
            else if (fmEnvMode == 1)
            {
                if (fmEnvLevel - decayRate > fmEnvSustain)
                {
                    fmEnvLevel -= decayRate;
                }
                else
                {
                    fmEnvLevel = fmEnvSustain;
                    fmEnvMode = 0;
                }
            }
            break;
        default:
            break;
        }
        DBG("fmEnvLevel: " << fmEnvLevel <<" fmEnvSelect: " << fmEnvSelect << " fmEnvMode: " << fmEnvMode << " attackRate: " << attackRate << " decayRate: " << decayRate << " counter : " << counter);
    }
    else
    {
        setFrequency(midiNoteFreq); // test
    }
}

void OscData::renderNextBlock (juce::dsp::AudioBlock<float>& audioBlock)
{
    jassert (audioBlock.getNumSamples() > 0);
    process (juce::dsp::ProcessContextReplacing<float> (audioBlock));
    gain.process (juce::dsp::ProcessContextReplacing<float> (audioBlock));
}

float OscData::processNextSample (float input)
{
    if(fmEnable)
    {
        fmModulator = fmOsc.processSample(input) * fmDepth * fmEnvLevel;

    }
    counter++;
    return gain.processSample (processSample (input));
}

void OscData::setParams(const bool oscEnable, const WaveMixData oscWave, const float oscGain, const int oscPitch, const FmData fm, const FmEnvData fmEnv)
{
    setType (oscWave, oscEnable);
    setGain (oscGain);
    setOscPitch (oscPitch);
    setFmOsc (fm, fmEnv);
}

void OscData::resetAll()
{
    reset();
    fmOsc.reset();
    gain.reset();
}
