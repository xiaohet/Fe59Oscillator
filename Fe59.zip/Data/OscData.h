/*
  ==============================================================================

    OscData.h
    Author:  Xiaohe Tian

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "AdsrData.h"

struct WaveMixData
{
    float sine;
    float square;
    float triangle;
    float saw;
};

struct FmData
{
    bool enable;
    float freq;
    float depth;
};

struct FmEnvData
{
    int select;
    float attack;
    float decay;
    float sustain;
};

class OscData : public juce::dsp::Oscillator<float>
{
public:
    void prepareToPlay (double sampleRate, int samplesPerBlock, int outputChannels);
    void setType (WaveMixData oscWave, const bool oscEnable);
    void setGain (const float levelInDecibels);
    void setOscPitch (const int pitch);
    void setFreq (const int midiNoteNumber);
    void setFmOsc (FmData fm, FmEnvData fmEnv);
    void renderNextBlock (juce::dsp::AudioBlock<float>& audioBlock);
    float processNextSample (float input);
    void setParams(const bool oscEnable, const WaveMixData oscWave, const float oscGain, const int oscPitch, const FmData fm, const FmEnvData fmEnv);
    void resetAll();

private:
    juce::dsp::Oscillator<float> fmOsc { [](float x) { return std::sin (x); }};
    juce::dsp::Gain<float> gain;
    AdsrData fmAdsr;
    int lastPitch { 0 };
    int lastMidiNote { 0 };
    bool fmEnable{ false };
    float fmDepth { 0.0f };
    float fmModulator { 0.0f };
    int fmEnvSelect{ 0 };
    float fmEnvAttack { 0.0f };
    float fmEnvDecay{ 0.0f };
    float fmEnvSustain{ 0.0f };
    float fmEnvLevel{ 1.0f };
    float attackRate{ 0.0f };
    float decayRate{ 0.0f };
    int fmEnvMode{ 0 };
    double sampRate;
    int counter;
};

// return std::sin (x); //Sine Wave
// return x / MathConstants<float>::pi; // Saw Wave
// return x < 0.0f ? -1.0f : 1.0f;  // Square Wave
