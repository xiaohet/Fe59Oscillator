/*
  ==============================================================================

    MasterComponent.cpp
    Author:  Xiaohe Tian

  ==============================================================================
*/

#include <JuceHeader.h>
#include "MasterComponent.h"

//==============================================================================
MasterComponent::MasterComponent(juce::AudioProcessorValueTreeState& apvts, juce::String masterGainId, juce::String panId, juce::String sizeId, juce::String dampingId, juce::String widthId, juce::String mixId, juce::String freezeId, juce::String attackId, juce::String decayId, juce::String sustainId, juce::String releaseId)
    : masterGain("Gain", masterGainId, apvts, dialWidth, dialHeight, " dB")
    , masterPan("Pan", panId, apvts, dialWidth, dialHeight, "")
    , size("Size", sizeId, apvts, vSliderWidth, vSliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , damping("Damping", dampingId, apvts, vSliderWidth, vSliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , stereoWidth("Width", widthId, apvts, vSliderWidth, vSliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , mix("Mix", mixId, apvts, vSliderWidth, vSliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , freeze("Freeze", freezeId, apvts, vSliderWidth, vSliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , attack("Attack", attackId, apvts, dialWidth, dialHeight, " s")
    , decay("Decay", decayId, apvts, dialWidth, dialHeight, " s")
    , sustain("Sustain", sustainId, apvts, dialWidth, dialHeight, "")
    , release("Release", releaseId, apvts, dialWidth, dialHeight, " s")
{
    addAndMakeVisible(masterGain);
    addAndMakeVisible(masterPan);
    addAndMakeVisible(size);
    addAndMakeVisible(damping);
    addAndMakeVisible(stereoWidth);
    addAndMakeVisible(mix);
    addAndMakeVisible(freeze);
    addAndMakeVisible(attack);
    addAndMakeVisible(decay);
    addAndMakeVisible(sustain);
    addAndMakeVisible(release);
}

MasterComponent::~MasterComponent()
{
}

void MasterComponent::resized()
{
    const auto xStart = 20;
    const auto yStart = 15;
    const auto vWidth = vSliderWidth;
    const auto vHeight = vSliderHeight + 20;
    const auto width = dialWidth;
    const auto height = dialHeight + 20;

    masterGain.setBounds(20, 35, width, height);
    masterPan.setBounds(masterGain.getRight() + 120, 35, width, height);

    size.setBounds(15, getY() + 125, vWidth, vHeight);
    damping.setBounds(size.getRight(), size.getY(), vWidth, vHeight);
    stereoWidth.setBounds(damping.getRight(), size.getY(), vWidth, vHeight);
    mix.setBounds(stereoWidth.getRight(), size.getY(), vWidth, vHeight);
    freeze.setBounds(mix.getRight(), size.getY(), vWidth, vHeight);
    attack.setBounds(20, getY() + 255, width, height);
    decay.setBounds(attack.getRight(), attack.getY(), width, height);
    sustain.setBounds(decay.getRight(), attack.getY(), width, height);
    release.setBounds(sustain.getRight(), attack.getY(), width, height);
}

void MasterComponent::paint(juce::Graphics& g)
{
    // g.fillAll (juce::Colours::black);
    auto bounds = getLocalBounds();
    g.setColour(juce::Colours::white);
    g.drawRoundedRectangle(bounds.toFloat().reduced(3.0f), 3.0f, 1.0f);

    g.setColour(juce::Colours::whitesmoke);
    g.setFont(fontHeight);
    g.setFont(g.getCurrentFont().boldened());

    g.drawText("Master", 15, 5, 100, 20, juce::Justification::left);

    g.setColour(juce::Colour::fromRGB(64, 128, 255));
    g.drawRoundedRectangle(size.getX() -7, size.getY() - 32, freeze.getRight() - size.getX() + 14, size.getBottom() - size.getY() + 39, 3.0f, 1.0f);
    g.setColour(juce::Colours::whitesmoke);
    g.setFont(fontHeight);
    g.drawText("Reverb", size.getX(), size.getY() - 25, 100, 20, juce::Justification::left);

    g.setColour(juce::Colour::fromRGB(64, 128, 255));
    g.drawRoundedRectangle(attack.getX() - 12, attack.getY() - 32, release.getRight() - attack.getX() + 24, attack.getBottom() - attack.getY() + 39, 3.0f, 1.0f);
    g.setColour(juce::Colours::whitesmoke);
    g.setFont(fontHeight);
    g.drawText("ADSR", attack.getX(), attack.getY() - 25, 100, 20, juce::Justification::left);

}

