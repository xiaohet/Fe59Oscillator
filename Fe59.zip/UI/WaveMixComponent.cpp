/*
  ==============================================================================

    WaveMixComponent.cpp
    Author:  Xiaohe Tian

  ==============================================================================
*/

#include <JuceHeader.h>
#include "WaveMixComponent.h"

//==============================================================================
WaveMixComponent::WaveMixComponent(juce::AudioProcessorValueTreeState& apvts, juce::String sineMixId, juce::String squareMixId, juce::String triangleMixId, juce::String sawMixId)
    : sine("Sine", sineMixId, apvts, sliderWidth, sliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , square("Square", squareMixId, apvts, sliderWidth, sliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , triangle("Triangle", triangleMixId, apvts, sliderWidth, sliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
    , saw("Saw", sawMixId, apvts, sliderWidth, sliderHeight, "", juce::Slider::SliderStyle::LinearVertical)
{

    addAndMakeVisible(sine);
    addAndMakeVisible(square);
    addAndMakeVisible(triangle);
    addAndMakeVisible(saw);
}

WaveMixComponent::~WaveMixComponent()
{
}

void WaveMixComponent::resized()
{
    const auto width = sliderWidth;
    const auto height = sliderHeight + 20;

    sine.setBounds(15, 25, width, height);
    square.setBounds(sine.getRight(), 25, width, height);
    triangle.setBounds(square.getRight(), 25, width, height);
    saw.setBounds(triangle.getRight(), 25, width, height);
}

