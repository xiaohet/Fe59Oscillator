/*
  ==============================================================================

    FmComponent.h
    Author:  Xiaohe Tian

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "CustomComponent.h"

//==============================================================================
/*
*/
class FmComponent : public CustomComponent
{
public:
    FmComponent(juce::AudioProcessorValueTreeState& apvts, juce::String fmEnable, juce::String freqId, juce::String depthId);
    ~FmComponent() override;

    void resized() override;

    static constexpr int getTotalWidth() { return totalWidth; }
    static constexpr int getTotalHeight() { return totalHeight; }

private:

    juce::ToggleButton enable;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> fmEnableAttachment;

    SliderWithLabel freq;
    SliderWithLabel depth;

    static constexpr int totalWidth = 150;
    static constexpr int totalHeight = 120;
    static constexpr int dialWidth = 60;
    static constexpr int dialHeight = 60;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(FmComponent)
};
