/*
  ==============================================================================

    ReverbComponent.cpp
    Created: 19 Feb 2021 9:18:11pm
    Author:  Joshua Hodge

  ==============================================================================
*/

#include <JuceHeader.h>
#include "ReverbComponent.h"

//==============================================================================
ReverbComponent::ReverbComponent (juce::AudioProcessorValueTreeState& apvts, juce::String sizeId, juce::String dampingId, juce::String widthId, juce::String mixId)
: size ("Size", sizeId, apvts, dialWidth, dialHeight, "")
, damping ("Damping", dampingId, apvts, dialWidth, dialHeight, "")
, stereoWidth ("Width", widthId, apvts, dialWidth, dialHeight, "")
, mix ("Mix", mixId, apvts, dialWidth, dialHeight, "")
{
    addAndMakeVisible (size);
    addAndMakeVisible (damping);
    addAndMakeVisible (stereoWidth);
    addAndMakeVisible (mix);
    
    setName ("Reverb");
}

ReverbComponent::~ReverbComponent()
{
}

void ReverbComponent::resized()
{
    const auto xStart = 5;
    const auto yStart = 5;
    const auto width = dialWidth;
    const auto height = dialHeight + 20;
    
    size.setBounds (xStart, yStart, width, height);
    damping.setBounds (size.getRight(), yStart, width, height);
    stereoWidth.setBounds (damping.getRight(), yStart, width, height);
    mix.setBounds (stereoWidth.getRight(), yStart, width, height);
}

