/*
  ==============================================================================

    AdsrComponent.cpp
    Created: 7 Feb 2021 2:28:49pm
    Author:  Joshua Hodge

  ==============================================================================
*/

#include <JuceHeader.h>
#include "AdsrComponent.h"

//==============================================================================
AdsrComponent::AdsrComponent (juce::AudioProcessorValueTreeState& apvts, juce::String attackId, juce::String decayId, juce::String sustainId, juce::String releaseId)
: attack ("A", attackId, apvts, dialWidth, dialHeight, " s")
, decay ("D", decayId, apvts, dialWidth, dialHeight, " s")
, sustain ("S", sustainId, apvts, dialWidth, dialHeight, "")
, release("R", releaseId, apvts, dialWidth, dialHeight, " s")
{
    addAndMakeVisible (attack);
    addAndMakeVisible (decay);
    addAndMakeVisible (sustain);
    addAndMakeVisible (release);
}

AdsrComponent::~AdsrComponent()
{
}

void AdsrComponent::resized()
{
    const auto startX = 5;
    const auto startY = 5;
    const auto width = dialWidth;
    const auto height = dialHeight + 20;
    
    attack.setBounds (startX, startY, width, height);
    decay.setBounds (attack.getRight(), startY, width, height);
    sustain.setBounds (decay.getRight(), startY, width, height);
    release.setBounds (sustain.getRight(), startY, width, height);
}

