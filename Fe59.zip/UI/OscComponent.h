/*
  ==============================================================================

    OscComponent.h
    Author:  Xiaohe Tian

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "CustomComponent.h"
#include "FmAdsrComponent.h"
#include "FmComponent.h"

//==============================================================================
/*
*/
class OscComponent : public CustomComponent
{
public:
    OscComponent(juce::AudioProcessorValueTreeState& apvts, juce::String enableId, juce::String gainId, juce::String pitchId);
    ~OscComponent() override;

    void resized() override;
    static constexpr int getTotalWidth() { return totalWidth; }
    static constexpr int getTotalHeight() { return totalHeight; }

    juce::TextButton enable;

private:
    //juce::ComboBox oscSelector; // not used in Fe59
    //std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> oscSelAttachment; // not used in Fe59
    
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> oscEnableAttachment;

    SliderWithLabel gain;
    // SliderWithLabel pan;
    SliderWithLabel pitch;
    // SliderWithLabel mix;
    // waveViewer in PluginProcessor
    
    static constexpr int totalWidth = 170;
    static constexpr int totalHeight = 120;
    static constexpr int dialWidth = 70;
    static constexpr int dialHeight = 60;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (OscComponent)
};
