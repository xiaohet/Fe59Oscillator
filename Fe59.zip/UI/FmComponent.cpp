/*
  ==============================================================================

    FmComponent.cpp
    Author:  Xiaohe Tian

  ==============================================================================
*/

#include <JuceHeader.h>
#include "FmComponent.h"

//==============================================================================
FmComponent::FmComponent(juce::AudioProcessorValueTreeState& apvts, juce::String fmEnable, juce::String freqId, juce::String depthId)
    : freq("FM Freq", freqId, apvts, dialWidth, dialHeight, " Hz", juce::Slider::SliderStyle::Rotary)
    , depth("FM Depth", depthId, apvts, dialWidth, dialHeight, "", juce::Slider::SliderStyle::Rotary)
{
    enable.setButtonText("On");
    addAndMakeVisible(enable);
    fmEnableAttachment = (std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>)
        new  juce::AudioProcessorValueTreeState::ButtonAttachment(apvts, fmEnable, enable);


    addAndMakeVisible(freq);
    addAndMakeVisible(depth);
}

FmComponent::~FmComponent()
{
}

void FmComponent::resized()
{
    const auto width = dialWidth;
    const auto height = dialHeight + 20;

    enable.setBounds(getTotalWidth() - 80, 5, 50, 20);
    freq.setBounds(15, enable.getBottom() + 5, width, height);
    depth.setBounds(freq.getRight(), enable.getBottom() + 5, width, height);
}

