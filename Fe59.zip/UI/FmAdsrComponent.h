/*
  ==============================================================================

    FmAdsrComponent.h
    Author:  Xiaohe Tian

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "CustomComponent.h"

//==============================================================================
/*
*/
class FmAdsrComponent : public CustomComponent
{
public:
    FmAdsrComponent(juce::AudioProcessorValueTreeState& apvts, juce::String fmAdsrSelect, juce::String attackId, juce::String decayId, juce::String sustainId);
    ~FmAdsrComponent() override;

    void resized() override;

    static constexpr int getTotalWidth() { return totalWidth; }
    static constexpr int getTotalHeight() { return totalHeight; }
private:

    juce::ComboBox select;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> fmAdsrSelectAttachment;

    SliderWithLabel attack;
    SliderWithLabel decay;
    SliderWithLabel sustain;

    static constexpr int totalWidth = 210;
    static constexpr int totalHeight = 120;
    static constexpr int dialWidth = 60;
    static constexpr int dialHeight = 60;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(FmAdsrComponent)
};
