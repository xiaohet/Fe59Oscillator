/*
  ==============================================================================

    WaveMixComponent.h
    Author:  Xiaohe Tian

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "CustomComponent.h"

//==============================================================================
/*
*/
class WaveMixComponent : public CustomComponent
{
public:
    WaveMixComponent(juce::AudioProcessorValueTreeState& apvts, juce::String sineMixId, juce::String squareMixId, juce::String triangleMixId, juce::String sawMixId);
    ~WaveMixComponent() override;

    void resized() override;

    static constexpr int getTotalWidth() { return totalWidth; }
    static constexpr int getTotalHeight() { return totalHeight; }

private:

    SliderWithLabel sine;
    SliderWithLabel square;
    SliderWithLabel triangle;
    SliderWithLabel saw;


    static constexpr int totalWidth = 230;
    static constexpr int totalHeight = 120;
    static constexpr int sliderWidth = 50;
    static constexpr int sliderHeight = 65;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WaveMixComponent)
};
