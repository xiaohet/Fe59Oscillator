/*
  ==============================================================================

    MasterComponent.h
    Author:  Xiaohe Tian

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "CustomComponent.h"

//==============================================================================
/*
*/
class MasterComponent : public CustomComponent
{
public:
    MasterComponent(juce::AudioProcessorValueTreeState& apvts, juce::String masterGainId, juce::String panId, juce::String sizeId, juce::String dampingId, juce::String widthId, juce::String mixId, juce::String freezeId, juce::String attackId, juce::String decayId, juce::String sustainId, juce::String releaseId);
    ~MasterComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    SliderWithLabel masterGain;
    SliderWithLabel masterPan;

    SliderWithLabel size;
    SliderWithLabel damping;
    SliderWithLabel stereoWidth;
    SliderWithLabel mix;
    SliderWithLabel freeze;

    SliderWithLabel attack;
    SliderWithLabel decay;
    SliderWithLabel sustain;
    SliderWithLabel release;

    static constexpr int hSliderWidth = 200;
    static constexpr int hSliderHeight = 30;
    static constexpr int vSliderWidth = 50;
    static constexpr int vSliderHeight = 60;
    static constexpr int dialWidth = 60;
    static constexpr int dialHeight = 60;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MasterComponent)
};
