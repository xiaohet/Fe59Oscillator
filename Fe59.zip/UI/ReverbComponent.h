/*
  ==============================================================================

    ReverbComponent.h
    Created: 19 Feb 2021 9:18:11pm
    Author:  Joshua Hodge

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "CustomComponent.h"

//==============================================================================
/*
*/
class ReverbComponent  : public CustomComponent
{
public:
    ReverbComponent (juce::AudioProcessorValueTreeState& apvts, juce::String sizeId, juce::String dampingId, juce::String widthId, juce::String mixId);
    ~ReverbComponent() override;

    void resized() override;

private:
    SliderWithLabel size;
    SliderWithLabel damping;
    SliderWithLabel stereoWidth;
    SliderWithLabel mix;
    
    static constexpr int dialWidth = 50;
    static constexpr int dialHeight = 50;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ReverbComponent)
};
