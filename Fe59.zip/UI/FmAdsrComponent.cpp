/*
  ==============================================================================

    FmAdsrComponent.cpp
    Author:  Xiaohe Tian

  ==============================================================================
*/

#include <JuceHeader.h>
#include "FmAdsrComponent.h"

//==============================================================================
FmAdsrComponent::FmAdsrComponent(juce::AudioProcessorValueTreeState& apvts, juce::String fmAdsrSelect, juce::String attackId, juce::String decayId, juce::String sustainId)
    : attack("Attack", attackId, apvts, dialWidth, dialHeight, " s", juce::Slider::SliderStyle::Rotary)
    , decay("Decay", decayId, apvts, dialWidth, dialHeight, " s", juce::Slider::SliderStyle::Rotary)
    , sustain("Sustain", sustainId, apvts, dialWidth, dialHeight, "", juce::Slider::SliderStyle::Rotary)
{

    juce::StringArray fmAdsrChoices{ "Off", "ADS", "Wave"};
    select.addItemList(fmAdsrChoices, 1);
    select.setSelectedItemIndex(0);
    addAndMakeVisible(select);

    fmAdsrSelectAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(apvts, fmAdsrSelect, select);

    addAndMakeVisible(attack);
    addAndMakeVisible(decay);
    addAndMakeVisible(sustain);
}

FmAdsrComponent::~FmAdsrComponent()
{
}

void FmAdsrComponent::resized()
{
    const auto startX = 20; // to be changed
    const auto startY = 15; // to be changed
    const auto width = dialWidth;
    const auto height = dialHeight + 20;

    select.setBounds(getTotalWidth() - 120, 5, 90, 20);
    attack.setBounds(15, select.getBottom() + 5, width, height);
    decay.setBounds(attack.getRight(), select.getBottom() + 5, width, height);
    sustain.setBounds(decay.getRight(), select.getBottom() + 5, width, height);
}

