/*
  ==============================================================================

    OscComponent.cpp
    Author:  Xiaohe Tian

  ==============================================================================
*/

#include <JuceHeader.h>
#include "OscComponent.h"
#include "../PluginEditor.h"

//==============================================================================
OscComponent::OscComponent(juce::AudioProcessorValueTreeState& apvts, juce::String enableId, juce::String gainId, juce::String pitchId)
    : gain("Gain", gainId, apvts, dialWidth, dialHeight, " dB", juce::Slider::SliderStyle::Rotary)
    , pitch ("Pitch", pitchId, apvts, dialWidth, dialHeight, "", juce::Slider::SliderStyle::Rotary)
{

    addAndMakeVisible(enable);
    oscEnableAttachment = (std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>)
        new  juce::AudioProcessorValueTreeState::ButtonAttachment(apvts, enableId, enable);

    bool enableState = apvts.getRawParameterValue(enableId);
    enable.setToggleState(enableState, juce::NotificationType::dontSendNotification);
    if (enableState == true)
    {
        enable.setButtonText("Osc On");
        enable.setColour(juce::TextButton::buttonOnColourId, juce::Colour::fromRGB(192, 160, 0));
    }
    else
    {
        enable.setButtonText("Osc Off");
        enable.removeColour(juce::TextButton::buttonColourId);
    }
    enable.setClickingTogglesState(true);
    enable.onClick = [this]() {
        if (enable.getToggleState())
        {
            enable.setButtonText("Osc On");
            enable.setColour(juce::TextButton::buttonOnColourId, juce::Colour::fromRGB(192, 160, 0));
        }
        else
        {
            enable.setButtonText("Osc Off");
            enable.removeColour(juce::TextButton::buttonColourId);
        }
        };
    //juce::StringArray oscChoices { "Sine", "Saw", "Square" };
    //oscSelector.addItemList (oscChoices, 1);
    //oscSelector.setSelectedItemIndex (0);
    //addAndMakeVisible (oscSelector);
    
    //oscSelAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(apvts, oscId, oscSelector);
    
    addAndMakeVisible (gain);
    addAndMakeVisible (pitch);
}

OscComponent::~OscComponent()
{
}


void OscComponent::resized()
{
    const auto width = dialWidth;
    const auto height = dialHeight + 20;
    
    enable.setBounds(getTotalWidth() - 100, 5, 70, 20);
    gain.setBounds (15, enable.getBottom() + 15, width, height);
    pitch.setBounds (gain.getRight(), enable.getBottom() + 15, width, height);
}
